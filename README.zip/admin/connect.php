<?php

$conn = mysqli_connect('localhost','logistics','logistics1972#','logistics_company');

if(!$conn)
{
    echo 'cannot connect to database server';
    exit;
}

?>